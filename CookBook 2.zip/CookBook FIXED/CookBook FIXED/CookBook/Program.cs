﻿using CookBook.Models;
using Microsoft.EntityFrameworkCore;
using CookBook.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Antiforgery;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Configure EF with SQL Server
builder.Services.AddDbContext<CookBookContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Identity
builder.Services.AddIdentity<Users, Roles>()
    .AddEntityFrameworkStores<CookBookContext>()
    .AddDefaultTokenProviders();

builder.Services.AddScoped<UserManager<Users>>();
builder.Services.AddScoped<RoleManager<Roles>>(); // Opcjonalnie, jeśli zarządzasz rolami

builder.Services.AddAntiforgery(options =>
{
    options.Cookie.SecurePolicy = CookieSecurePolicy.Always; // Oznacz ciasteczka jako Secure
    options.Cookie.HttpOnly = true; // Zapobiega dostępowi z JavaScript
    options.Cookie.SameSite = SameSiteMode.Strict; // Zwiększa bezpieczeństwo
});

builder.Services.ConfigureApplicationCookie(options =>
{
    options.Cookie.SecurePolicy = CookieSecurePolicy.Always; // Ustaw cookie tylko dla HTTPS
    options.Cookie.SameSite = SameSiteMode.Strict; // Największe bezpieczeństwo
    options.Cookie.HttpOnly = true; // Zapobiega dostępowi przez JavaScript
    options.ExpireTimeSpan = TimeSpan.FromMinutes(60); // Ciasteczko wygasa po 60 minutach
    options.SlidingExpiration = true; // Odnawianie czasu ważności ciasteczka przy aktywności
});


var app = builder.Build();
// Apply migrations and create the database if it doesn't exist
ApplyMigrations(app);

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.Use(async (context, next) =>
{
    if (context.Request.Method == "POST")
    {
        var antiforgery = app.Services.GetRequiredService<IAntiforgery>();
        await antiforgery.ValidateRequestAsync(context);
    }
    await next();
});

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();

void ApplyMigrations(IHost app)
{
    using (var scope = app.Services.CreateScope())
    {
        var services = scope.ServiceProvider;
        try
        {
            var context = services.GetRequiredService<CookBookContext>();
            context.Database.Migrate();
        }
        catch (Exception ex)
        {
            var logger = services.GetRequiredService<ILogger<Program>>();
            logger.LogError(ex, "An error occurred applying migrations. Details: {Message}", ex.Message);
        }
    }
}
