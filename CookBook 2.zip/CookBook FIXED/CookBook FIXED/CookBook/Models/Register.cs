﻿using System.ComponentModel.DataAnnotations;


namespace CookBook.Models
{
    public class Register
    {
        [Required]
        [StringLength(100, ErrorMessage = "Username must be at least 6 characters long.", MinimumLength = 6)]
        public string Username { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "Password must be at least 6 characters long.", MinimumLength = 6)]
        public string Password { get; set; }

        [Required]
        [Compare("Password", ErrorMessage = "Passwords must be the same.")]
        public string ConfirmPassword { get; set; }

    }
}
