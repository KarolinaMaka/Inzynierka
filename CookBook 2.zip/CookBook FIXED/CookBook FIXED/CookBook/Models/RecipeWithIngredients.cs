﻿using System.ComponentModel.DataAnnotations;

namespace CookBook.Models
{
    public class RecipeWithIngredients
    {
        [Key]
        public int RecipeWithIngredientsID { get; set; }
        public int RecipeID { get; set; }
        public Recipes Recipe { get; set; }

        public int IngredientID { get; set; }
        public Ingredients Ingredient { get; set; }

        public double Quantity { get; set; }
        public string Unit { get; set; }
    }
}
