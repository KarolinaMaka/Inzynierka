﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;

namespace CookBook.Models
{
    public class Users : IdentityUser <Guid>
    {
        public Guid RoleID { get; set; } 
        public Roles Role { get; set; } 

        // Relacje
        public ICollection<Recipes> Recipes { get; set; }
        public ICollection<LikedRecipes> LikedRecipes { get; set; }
        public ICollection<SavedRecipes> SavedRecipes { get; set; }
    }
}
