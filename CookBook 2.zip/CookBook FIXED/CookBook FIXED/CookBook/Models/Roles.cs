﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace CookBook.Models
{
    public class Roles : IdentityRole<Guid>
    {
        public string RoleName { get; set; }

        public ICollection<Users> Users { get; set; }

    }
}
