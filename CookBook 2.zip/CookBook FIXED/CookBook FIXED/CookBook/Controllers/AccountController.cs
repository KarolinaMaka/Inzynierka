﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using CookBook.Models;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace CookBook.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<Users> _userManager;
        private readonly SignInManager<Users> _signInManager;

        public AccountController(UserManager<Users> userManager, SignInManager<Users> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        // Akcja rejestracji
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(Register model)
        {
            if (ModelState.IsValid)
            {
                var user = new Users
                {
                    UserName = model.Username,
                    Email = model.Email,
                };

                var result = await _userManager.CreateAsync(user, model.Password);

                if (result.Succeeded)
                {
                    // Możesz dodać przypisanie roli, jeśli masz rolę dla użytkownika
                    await _userManager.AddToRoleAsync(user, "User");

                    // Jeśli masz włączoną weryfikację e-mail, wyślij potwierdzenie
                    var token = await _userManager.GenerateEmailConfirmationTokenAsync(user);
                    var confirmationLink = Url.Action("ConfirmEmail", "Account", new { userId = user.Id, token = token }, Request.Scheme);

                    // Wysłanie linku potwierdzającego email
                    // await _emailSender.SendEmailAsync(user.Email, "Potwierdzenie rejestracji", confirmationLink);

                    // Logowanie po rejestracji
                    await _signInManager.SignInAsync(user, isPersistent: false);
                    return RedirectToAction("Index", "Home");  // Przekierowanie po rejestracji
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
            }

            return View(model);
        }

        // Akcja logowania
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
       [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(Login model, string returnUrl = null)
        {
            returnUrl ??= Url.Content("~/");

            if (ModelState.IsValid)
            {
                // Znajdź użytkownika
                var user = await _userManager.FindByNameAsync(model.Username);

                if (user != null)
                {
                    // Możliwość sprawdzenia, czy email jest zweryfikowany
                    if (!user.EmailConfirmed)
                    {
                        ModelState.AddModelError(string.Empty, "Please confirm your email first.");
                        return View(model);
                    }

                    // Próbuj zalogować użytkownika
                    var result = await _signInManager.PasswordSignInAsync(user, model.Password, model.RememberMe, false);

                    if (result.Succeeded)
                    {
                        return LocalRedirect(returnUrl);
                    }

                    ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                }
            }

            return View(model);
        }

        // Wylogowanie
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }

        // Potwierdzenie e-maila po rejestracji
        public async Task<IActionResult> ConfirmEmail(string userId, string token)
        {
            var user = await _userManager.FindByIdAsync(userId);

            if (user == null)
            {
                return RedirectToAction("Index", "Home");
            }

            var result = await _userManager.ConfirmEmailAsync(user, token);

            if (result.Succeeded)
            {
                // Możesz przekierować do strony logowania lub powiadomić o sukcesie
                return RedirectToAction("Login", "Account");
            }

            return RedirectToAction("Index", "Home");
        }
    }
}
