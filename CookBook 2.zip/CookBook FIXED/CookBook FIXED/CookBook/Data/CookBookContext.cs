﻿using System;
using CookBook.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;

namespace CookBook.Data
{
    public partial class CookBookContext : IdentityDbContext<Users, Roles, Guid>
    {
        public CookBookContext() 
        {
        }

        public CookBookContext(DbContextOptions<CookBookContext> options)
            : base(options)
        {
        }

        // DbSet dla  tabel
        public virtual DbSet<Ingredients> Ingredients { get; set; }
        public virtual DbSet<LikedRecipes> LikedRecipes { get; set; }
        public virtual DbSet<Recipes> Recipes { get; set; }
        public virtual DbSet<RecipeWithIngredients> RecipeWithIngredients { get; set; }
        public virtual DbSet<RecipeWithTags> RecipeWithTags { get; set; }
        public virtual DbSet<SavedRecipes> SavedRecipes { get; set; }
        public virtual DbSet<Tags> Tags { get; set; }
        public virtual DbSet<Users> Users { get; set; }
        public virtual DbSet<Roles> Roles {  get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(
                    "Server=KAROLINA-LAPTOP;Database=CookBook;Trusted_Connection=True;MultipleActiveResultSets=true;Encrypt=False",
                    options => options.EnableRetryOnFailure());
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder); // Konieczne, aby Identity działało poprawnie

            // Konfiguracja tabeli Ingredients
            modelBuilder.Entity<Ingredients>(entity =>
            {
                entity.ToTable("Ingredients"); // Mapowanie na istniejącą tabelę
                entity.HasKey(e => e.IngredientID); // Główne klucz
                entity.Property(e => e.IngredientName).IsRequired().HasMaxLength(100);
            });

            

            // Konfiguracja tabeli Recipes
            modelBuilder.Entity<Recipes>(entity =>
            {
                entity.ToTable("Recipes"); // Mapowanie na istniejącą tabelę
                entity.HasKey(e => e.RecipeID); // Główne klucz
                entity.Property(e => e.RecipeName).IsRequired().HasMaxLength(200);
            });

            // Konfiguracja tabeli Roles (IdentityRole z mapowaniem na RoleID)
            modelBuilder.Entity<Roles>(entity =>
            {
                entity.ToTable("Roles"); // Mapowanie na istniejącą tabelę
                entity.HasKey(e => e.Id); // Główne klucz (Id w modelu, RoleID w bazie)
                entity.Property(e => e.Id).HasColumnName("RoleID").HasColumnType("uniqueidentifier");
                
            });

            // Konfiguracja tabeli Users
            modelBuilder.Entity<Users>(entity =>
            {
                entity.ToTable("Users"); // Mapowanie na istniejącą tabelę
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).ValueGeneratedOnAdd(); //automatyczne generowanie klucza glownego
                entity.Property(e => e.Id).HasColumnName("UserID").HasColumnType("uniqueidentifier");
                entity.Property(e => e.UserName).IsRequired().HasMaxLength(256);
                
            });

            // Relacje między Users i Roles
            modelBuilder.Entity<Users>(entity =>
            {
                entity.HasOne(u => u.Role) // Relacja z rolą
                    .WithMany()
                    .HasForeignKey(u => u.RoleID) // Klucz obcy
                    .OnDelete(DeleteBehavior.Cascade);
            });

            //
            modelBuilder.Entity<IdentityUserRole<Guid>>(entity =>
            {
                entity.HasKey(e => new { e.UserId, e.RoleId });

                entity.HasOne<Users>()
                    .WithMany()
                    .HasForeignKey(e => e.UserId)
                    .IsRequired();
            });

            // Konfiguracja tabeli RecipeWithIngredients
            modelBuilder.Entity<RecipeWithIngredients>(entity =>
            {
                entity.ToTable("RecipeWithIngredients");
                entity.HasKey(e => e.RecipeWithIngredientsID);
                entity.HasOne(e => e.Recipe)
                    .WithMany(e => e.RecipeWithIngredients)
                    .HasForeignKey(e => e.RecipeID);
                entity.HasOne(e => e.Ingredient)
                    .WithMany()
                    .HasForeignKey(e => e.IngredientID);
            });

            // Konfiguracja tabeli RecipeWithTags
            modelBuilder.Entity<RecipeWithTags>(entity =>
            {
                entity.ToTable("RecipeWithTags");
                entity.HasKey(e => e.RecipeWithTagsID);
                entity.HasOne(e => e.Recipe)
                    .WithMany(e => e.RecipeWithTags)
                    .HasForeignKey(e => e.RecipeID);
                entity.HasOne(e => e.Tag)
                    .WithMany()
                    .HasForeignKey(e => e.TagID);
            });

            // Konfiguracja tabeli LikedRecipes
            modelBuilder.Entity<LikedRecipes>(entity =>
            {
                entity.ToTable("LikedRecipes");
                entity.HasKey(e => e.LikedRecipeID);
                entity.HasOne(e => e.User)
                    .WithMany(e => e.LikedRecipes)
                    .HasForeignKey(e => e.UserID) //UserID
                    .OnDelete(DeleteBehavior.Cascade);
                entity.HasOne(e => e.Recipe)
                    .WithMany()
                    .HasForeignKey(e => e.RecipeID);
            });

            // Konfiguracja tabeli SavedRecipes
            modelBuilder.Entity<SavedRecipes>(entity =>
            {
                entity.ToTable("SavedRecipes");
                entity.HasKey(e => e.SavedRecipeID);
                entity.HasOne(e => e.User)
                    .WithMany(e => e.SavedRecipes)
                    .HasForeignKey(e => e.UserID)
                    .OnDelete(DeleteBehavior.Cascade);
                entity.HasOne(e => e.Recipe)
                    .WithMany()
                    .HasForeignKey(e => e.RecipeID);
            });


            /////asp tabele
            modelBuilder.Entity<IdentityUserClaim<Guid>>(entity =>
            {
                entity.ToTable("AspNetUserClaims");
                entity.HasKey(e => e.Id);

                entity.HasOne<Users>()
                    .WithMany()
                    .HasForeignKey(e => e.UserId)
                    .IsRequired();
            });

            modelBuilder.Entity<IdentityUserToken<Guid>>(entity =>
            {
                entity.ToTable("AspNetUserTokens");
                entity.HasKey(e => new { e.UserId, e.LoginProvider, e.Name });

                entity.HasOne<Users>()
                    .WithMany()
                    .HasForeignKey(e => e.UserId)
                    .IsRequired();
            });

            modelBuilder.Entity<IdentityRoleClaim<Guid>>(entity =>
            {
                entity.ToTable("AspNetRoleClaims");
                entity.HasKey(e => e.Id);

                entity.HasOne<Roles>()
                    .WithMany()
                    .HasForeignKey(e => e.RoleId)
                    .IsRequired();
            });

            modelBuilder.Entity<IdentityUserLogin<Guid>>(entity =>
            {
                entity.ToTable("AspNetUserLogins");
                entity.HasKey(e => new { e.LoginProvider, e.ProviderKey });

                entity.HasOne<Users>()
                    .WithMany()
                    .HasForeignKey(e => e.UserId)
                    .IsRequired();
            });




        }

    }
}
