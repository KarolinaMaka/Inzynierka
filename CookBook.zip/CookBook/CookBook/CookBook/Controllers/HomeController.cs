using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using CookBook.Models;
using CookBook.Data;

namespace CookBook.Controllers
{
    public class HomeController : Controller
    {
        private readonly CookBookContext _context;

        public HomeController(CookBookContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            try
            {
                //test
                var ingredients = _context.Ingredients.ToList();
                return View(ingredients); 
            }
            catch (Exception ex)
            {
                
                return View("Error", new { message = $"Brak polaczenia: {ex.Message}" });
            }
        }
    }
}
