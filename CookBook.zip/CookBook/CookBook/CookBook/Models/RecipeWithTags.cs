﻿using Azure;
using System.ComponentModel.DataAnnotations;

namespace CookBook.Models
{
    public class RecipeWithTags
    {
        [Key]
        public int RecipeWithTagsID { get; set; }   
        public int RecipeID { get; set; }
        public Recipes Recipe { get; set; }

        public string TagID { get; set; }
        public Tags Tag { get; set; }
    }
}
