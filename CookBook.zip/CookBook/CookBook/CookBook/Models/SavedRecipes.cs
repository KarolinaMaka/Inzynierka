﻿using System.ComponentModel.DataAnnotations;

namespace CookBook.Models
{
    public class SavedRecipes
    {
        [Key]
        public int SavedRecipeID { get; set; }
        public Guid UserID { get; set; }
        public Users User { get; set; }

        public int RecipeID { get; set; }
        public Recipes Recipe { get; set; }
    }
}
