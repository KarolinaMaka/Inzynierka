﻿using System.ComponentModel.DataAnnotations;

namespace CookBook.Models
{
    public class Roles
    {
        [Key]
        public int RoleID { get; set; }
        public string RoleName { get; set; }

        // Relacje
        public ICollection<Users> Users { get; set; }
    }
}
