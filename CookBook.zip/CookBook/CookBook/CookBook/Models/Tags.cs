﻿using System.ComponentModel.DataAnnotations;

namespace CookBook.Models
{
    public class Tags
    {
        [Key]
        public string TagID { get; set; }
        public string TagName { get; set; }

        // Relacje
        public ICollection<RecipeWithTags> RecipeWithTags { get; set; }
    }
}
