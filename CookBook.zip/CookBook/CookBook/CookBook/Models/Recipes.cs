﻿using System.ComponentModel.DataAnnotations;

namespace CookBook.Models
{
    public class Recipes
    {
        [Key]
        public int RecipeID { get; set; }
        public string RecipeName { get; set; }
        public string Instruction { get; set; }
        public int Servings { get; set; }
        public int CookingTimeMinutes { get; set; }

        // Relacja z User (Author)
        public Guid AuthorID { get; set; }
        public Users Author { get; set; }

        // Relacje
        public ICollection<RecipeWithIngredients> RecipeWithIngredients { get; set; }
        public ICollection<RecipeWithTags> RecipeWithTags { get; set; }
        public ICollection<LikedRecipes> LikedRecipes { get; set; }
        public ICollection<SavedRecipes> SavedRecipes { get; set; }
    }
}
