﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;

namespace CookBook.Models
{
    public class Users : IdentityUser <Guid>
    {
        //[Column("UserID")] // Mapowanie do UserID w bazie danych
        //public override Guid Id { get; set; }
        public Guid RoleID { get; set; } // FK do Roles
        public Roles Role { get; set; } // Nawigacja do Roles

        // Relacje
        public ICollection<Recipes> Recipes { get; set; }
        public ICollection<LikedRecipes> LikedRecipes { get; set; }
        public ICollection<SavedRecipes> SavedRecipes { get; set; }
    }
}
