﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace CookBook.Models
{
    public class Roles : IdentityRole<Guid>
    {
        //[Column("RoleID")] // Mapowanie do UserID w bazie danych
        //public override Guid Id { get; set; }
        public string RoleName { get; set; }

        public ICollection<Users> Users { get; set; }

    }
}
