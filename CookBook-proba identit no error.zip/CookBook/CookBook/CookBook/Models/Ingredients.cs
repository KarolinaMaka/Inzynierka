﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace CookBook.Models
{
    public class Ingredients
    {

        [Key]
        public int IngredientID { get; set; }
        public string IngredientName { get; set; }

        // Relacje
        public ICollection<RecipeWithIngredients> RecipeWithIngredients { get; set; }
    }
}
