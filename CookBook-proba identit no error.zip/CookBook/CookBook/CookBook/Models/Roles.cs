﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace CookBook.Models
{
    public class Roles : IdentityRole<Guid> 
    {
        [Key]
        public int RoleID { get; set; }  
        public string RoleName { get; set; }

        // Relacje
        public ICollection<Users> Users { get; set; }
    }
}
