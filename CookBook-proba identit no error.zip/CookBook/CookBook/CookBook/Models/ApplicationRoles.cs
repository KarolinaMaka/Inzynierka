﻿//using Microsoft.AspNetCore.Identity;

//namespace CookBook.Models
//{
//    public class ApplicationRoles : IdentityRole<int>
//    {
//        public int RoleID { get; set; }
//        public string RoleName { get; set; }

//        // Relacje
//        public ICollection<Users> Users { get; set; }
//    }
//}
