﻿//using Microsoft.AspNetCore.Identity;

//namespace CookBook.Models
//{
//    public class ApplicationUsers : IdentityUser<Guid>
//    {
//        public Guid UserID { get; set; }
//        public string Username { get; set; }
//        public string Email { get; set; }
//        public int RoleID { get; set; }

//        public virtual Roles Role { get; set; }

//        // Relacje
//        public ICollection<Recipes> Recipes { get; set; }
//        public ICollection<LikedRecipes> LikedRecipes { get; set; }
//        public ICollection<SavedRecipes> SavedRecipes { get; set; }

//    }
//}
