﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace CookBook.Models
{
    public class Users : IdentityUser<Guid>
    {
        [Key]
        public Guid UserID { get; set; }
        public string OAuthID {  get; set; }
        public string Username { get; set; }
        public string Email { get; set; }

        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }
        

        // Relacja z Role
        public int RoleID { get; set; }
        public Roles Role { get; set; }

        // Relacje
        public ICollection<Recipes> Recipes { get; set; }
        public ICollection<LikedRecipes> LikedRecipes { get; set; }
        public ICollection<SavedRecipes> SavedRecipes { get; set; }
    }
}
