﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CookBook.Models;

public partial class LikedRecipes
{
    [Key]
    public int LikedRecipeID { get; set; }

    public Guid UserID { get; set; }

    public int RecipeID { get; set; }

    public virtual Recipes Recipe { get; set; } = null!;

    public virtual Users User { get; set; } = null!;
}
