using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using CookBook.Models;
using CookBook.Data;
using System.Diagnostics;

namespace CookBook.Controllers
{
    public class HomeController : Controller
    {
        private readonly CookBookContext _context;

        public HomeController(CookBookContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            try
            {
                var ingredients = _context.Ingredients.ToList();
                return View(ingredients);
            }
            catch (Exception ex)
            {
                var errorModel = new ErrorViewModel
                {
                    RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier,
                    Message = $"No connection: {ex.Message}"
                };
                return View("Error", errorModel);
            }
        }
    }
}
