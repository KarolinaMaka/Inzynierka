﻿using System;
using System.Collections.Generic;
using CookBook.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace CookBook.Data;

public partial class CookBookContext : IdentityDbContext<Users, Roles, Guid>
    {
        public CookBookContext()
        {
        }

        public CookBookContext(DbContextOptions<CookBookContext> options)
            : base(options)
        {
        }

        // DbSet dla istniejących tabel
        public virtual DbSet<Ingredients> Ingredients { get; set; }
        public virtual DbSet<LikedRecipes> LikedRecipes { get; set; }
        public virtual DbSet<Recipes> Recipes { get; set; }
        public virtual DbSet<RecipeWithIngredients> RecipeWithIngredients { get; set; }
        public virtual DbSet<RecipeWithTags> RecipeWithTags { get; set; }
        public virtual DbSet<SavedRecipes> SavedRecipes { get; set; }
        public virtual DbSet<Tags> Tags { get; set; }
        public virtual DbSet<Users> Users { get; set; }
        public virtual DbSet<Roles> Roles { get; set; }

    



    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=KAROLINA-LAPTOP;Database=CookBook;Trusted_Connection=True;MultipleActiveResultSets=true;Encrypt=False");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        //base.OnModelCreating(modelBuilder); /////to moze powodowac blad

        


        //definicja klucza glownego w identityuserlogin
        modelBuilder.Entity<IdentityUserLogin<Guid>>(entity =>
        {
            // Definiowanie klucza kompozytowego
            entity.HasKey(login => new { login.LoginProvider, login.ProviderKey });

        });

        // dodanie klucza glownego do IdentityRole
        modelBuilder.Entity<IdentityUserRole<Guid>>(entity =>
        {
            // Definiowanie klucza kompozytowego
            entity.HasKey(role => new { role.UserId, role.RoleId });

            // Opcjonalnie: Dostosowanie nazw kolumn w bazie danych
            entity.Property(role => role.UserId).HasColumnName("UserID");
            entity.Property(role => role.RoleId).HasColumnName("RoleID");
        });

        modelBuilder.Entity<IdentityUserToken<Guid>>(entity =>
        {
            entity.HasKey(token => new { token.UserId, token.LoginProvider, token.Name });
            entity.Property(token => token.UserId).HasColumnName("UserID");
            entity.Property(token => token.LoginProvider).HasColumnName("LoginProvider");
            entity.Property(token => token.Name).HasColumnName("Name");
        });

        modelBuilder.Entity<IdentityRoleClaim<Guid>>(entity =>
        {
            entity.HasKey(roleClaim => roleClaim.Id); // Klucz główny
            entity.Property(roleClaim => roleClaim.Id).HasColumnName("RoleClaimID");
            entity.Property(roleClaim => roleClaim.RoleId).HasColumnName("RoleID");
        });

        modelBuilder.Entity<IdentityUserClaim<Guid>>(entity =>
        {
            entity.HasKey(userClaim => userClaim.Id); // Klucz główny
            entity.Property(userClaim => userClaim.Id).HasColumnName("UserClaimID");
            entity.Property(userClaim => userClaim.UserId).HasColumnName("UserID");
        });







        modelBuilder.Entity<Ingredients>(entity =>
        {
            entity.HasKey(e => e.IngredientID).HasName("PK__Ingredie__BEAEB27A144A860D");

            entity.Property(e => e.IngredientID).HasColumnName("IngredientID");
            entity.Property(e => e.IngredientName)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<LikedRecipes>(entity =>
        {
            entity.HasKey(e => e.LikedRecipeID).HasName("PK__LikedRec__A18E225A04384155");

            entity.Property(e => e.LikedRecipeID).HasColumnName("LikedRecipeID");
            entity.Property(e => e.RecipeID).HasColumnName("RecipeID");
            entity.Property(e => e.UserID).HasColumnName("UserID");

            entity.HasOne(d => d.Recipe).WithMany(p => p.LikedRecipes)
                .HasForeignKey(d => d.RecipeID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_LikedRecipes_Recipes");

            entity.HasOne(d => d.User).WithMany(p => p.LikedRecipes)
                .HasForeignKey(d => d.UserID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_LikedRecipes_Users");
        });

        modelBuilder.Entity<Recipes>(entity =>
        {
            entity.HasKey(e => e.RecipeID).HasName("PK__Recipes__FDD988D034100A03");

            entity.Property(e => e.RecipeID).HasColumnName("RecipeID");
            entity.Property(e => e.RecipeName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.Instruction).HasColumnType("text");
            entity.Property(e => e.Servings);
            entity.Property(e => e.CookingTimeMinutes);

            // Relacja z Users - klucz obcy
            entity.HasOne(d => d.Author)
                .WithMany(p => p.Recipes)
                .HasForeignKey(d => d.AuthorID)  // Klucz obcy
                .HasConstraintName("FK_Recipes_Users_AuthorID");
        });

        modelBuilder.Entity<RecipeWithIngredients>(entity =>
        {
            entity.HasKey(e => e.RecipeWithIngredientsID).HasName("PK__RecipeWi__99E9F478721D0DDF");

            entity.Property(e => e.RecipeWithIngredientsID).HasColumnName("RecipeWithIngredientsID");
            entity.Property(e => e.IngredientID).HasColumnName("IngredientID");
            entity.Property(e => e.RecipeID).HasColumnName("RecipeID");
            entity.Property(e => e.Unit)
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.HasOne(d => d.Ingredient).WithMany(p => p.RecipeWithIngredients)
                .HasForeignKey(d => d.IngredientID)
                .HasConstraintName("FK_IngredientID");

            entity.HasOne(d => d.Recipe).WithMany(p => p.RecipeWithIngredients)
                .HasForeignKey(d => d.RecipeID)
                .HasConstraintName("FK_RecipeID");
        });

        modelBuilder.Entity<RecipeWithTags>(entity =>
        {
            entity.HasKey(e => e.RecipeWithTagsID).HasName("PK__RecipeWi__7C2C11CEA613D836");

            entity.Property(e => e.RecipeWithTagsID).HasColumnName("RecipeWithTagID");
            entity.Property(e => e.RecipeID).HasColumnName("RecipeID");
            entity.Property(e => e.TagID).HasColumnName("TagID");

            entity.HasOne(d => d.Recipe).WithMany(p => p.RecipeWithTags)
                .HasForeignKey(d => d.RecipeID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__RecipeWit__Recip__73BA3083");

            entity.HasOne(d => d.Tag).WithMany(p => p.RecipeWithTags)
                .HasForeignKey(d => d.TagID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__RecipeWit__TagID__74AE54BC");
        });

        modelBuilder.Entity<Roles>(entity =>
        {
            entity.HasKey(e => e.RoleID).HasName("PK__Roles__8AFACE3A39021D75");

            // Konwersja RoleID giud =>int
            var guidToIntConverter = new ValueConverter<Guid, int>(
                v => BitConverter.ToInt32(v.ToByteArray(), 0),  // Konwersja z Guid na int
                v => new Guid(v.ToString("D").PadLeft(32, '0')) // Konwersja z int na Guid
            );

            ////konwersja typów
            modelBuilder.Entity<Roles>()
           .Property(e => e.Id) // Właściwość `Id` w ASP.NET Identity
           .HasConversion(guidToIntConverter) // Ustawienie konwertera
           .HasColumnName("RoleID") // Kolumna w bazie danych
           .IsRequired();

            entity.Property(e => e.RoleID).HasColumnName("RoleID");
            entity.Property(e => e.RoleName)
                .HasMaxLength(15)
                .IsUnicode(false);

            entity.Ignore(e => e.Id); //?



        });
        



        modelBuilder.Entity<SavedRecipes>(entity =>
        {
            entity.HasKey(e => e.SavedRecipeID).HasName("PK__SavedRec__AEEB3B49E832659D");

            entity.Property(e => e.SavedRecipeID).HasColumnName("SavedRecipeID");
            entity.Property(e => e.RecipeID).HasColumnName("RecipeID");
            entity.Property(e => e.UserID).HasColumnName("UserID");

            entity.HasOne(d => d.Recipe).WithMany(p => p.SavedRecipes)
                .HasForeignKey(d => d.RecipeID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SavedRecipes_Recipes");

            entity.HasOne(d => d.User).WithMany(p => p.SavedRecipes)
                .HasForeignKey(d => d.UserID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SavedRecipes_Users");
        });

        modelBuilder.Entity<Tags>(entity =>
        {
            entity.HasKey(e => e.TagID).HasName("PK__Tags__657CFA4CC5E21E3C");

            entity.Property(e => e.TagID).HasColumnName("TagID");
            entity.Property(e => e.TagName).HasMaxLength(40);
        });

        modelBuilder.Entity<Users>(entity =>
        {
            entity.HasKey(e => e.UserID).HasName("PK__Users__1788CCAC3DF4E977");

            entity.HasIndex(e => e.Username, "UQ_Users_UserName").IsUnique();

            entity.Property(e => e.UserID)
                .HasDefaultValueSql("(newid())")
                .HasColumnName("UserID");
            entity.Property(e => e.AccessToken)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.OAuthID)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("OAuthID");
            entity.Property(e => e.RefreshToken)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.RoleID)
                .HasDefaultValue(3)
                .HasColumnName("RoleID");
            entity.Property(e => e.Username)
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.HasOne(d => d.Role).WithMany(p => p.Users)
                .HasForeignKey(d => d.RoleID)
                .HasConstraintName("FK_Users_Roles");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
